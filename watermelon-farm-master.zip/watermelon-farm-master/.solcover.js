module.exports = {
  skipFiles: [
    "libs",
    "libs",
    "libs",
    "SyrupBar.sol",
    "CakeToken.sol",
    "Timelock.sol",
  ],
  measureStatementCoverage: false,
  measureFunctionCoverage: true,
};
