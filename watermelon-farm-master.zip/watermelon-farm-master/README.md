# Watermelon Farm :watermelon:

Watermelon Farm is an AMM and Yield Farm based on the Binance Smart Chain.  
It aims to make many aspects of yield farming and liquidity mining more accessible users who are new to the space.  
It does this by gamifying the mechanics of yield farming, and changing the language to be more understandable.

## Technology :technologist:

Watermelon Farm is a fork of Pancake Swap, with no changes made to the smart contracts other than name changes.  
The intent here is to build ontop of an audited and trusted model that has been proven over time.

## Development :balloon:

Watermelon Farm is still in active development.  
We are planning a release some time early to mid March.
