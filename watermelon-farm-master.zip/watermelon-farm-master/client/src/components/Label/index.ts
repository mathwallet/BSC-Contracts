export { default } from "./Label";
