export { default } from "./Input";
export type { InputProps } from "./Input";
