export { default } from "./Syrup";
