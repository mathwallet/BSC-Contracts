// Copyright (c) Aptos
// SPDX-License-Identifier: Apache-2.0
pub use move_core_types::vm_status::{
    known_locations, sub_status, AbortLocation, DiscardedVMStatus, KeptVMStatus, StatusCode,
    StatusType, VMStatus,
};
