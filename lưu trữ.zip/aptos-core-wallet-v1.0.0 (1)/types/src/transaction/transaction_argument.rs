// Copyright (c) Aptos
// SPDX-License-Identifier: Apache-2.0

pub use move_core_types::{
    parser::parse_transaction_argument, transaction_argument::TransactionArgument,
};
