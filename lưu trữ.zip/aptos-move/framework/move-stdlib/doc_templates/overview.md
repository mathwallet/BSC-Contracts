# Move Stdlib Modules

This is the root document for the Move stdlib module documentation. The Move stdlib provides modules that can be used to access or interact with core language features.

## Index

> {{move-index}}
