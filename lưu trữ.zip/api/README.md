# Aptos Node API

This module provides a REST API for client applications to query the Aptos blockchain.

See spec source:
- [YAML in doc/spec.yaml](doc/spec.yaml).
- [JSON in doc/spec.json](doc/spec.json).
- [HTML in doc/spec.html](doc/spec.html).
